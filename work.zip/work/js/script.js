var pathValues = [
"M160.4,-90.1C187.9,-44.8,176.7,25.3,143.5,75.8C110.3,126.3,55.1,157.2,2.3000000000000007,155.8C-50.5,154.5,-101,121,-140.2,67.1C-179.3,13.2,-207,-61.2,-181.7,-105.1C-156.5,-149,-78.2,-162.5,-5.9,-159.1C66.4,-155.7,132.8,-135.3,160.4,-90.1Z",
"M88.6,-62.8C115.5,-4.7,138.3,44.2,122.8,79.6C107.4,115,53.7,137,-7.8,141.5C-69.3,146,-138.6,133,-173.6,86.3C-208.7,39.5,-209.6,-41,-174.9,-103.7C-140.3,-166.3,-70.1,-211.2,-19.6,-199.8C30.9,-188.5,61.8,-121,88.6,-62.8Z"];


$(document).ready(function () {
  var wiggle = anime({
    targets: ".blob",
    d: [{ value: pathValues }],
    easing: "easeInOutSine",
    duration: 5000,
    direction: "alternate",
    loop: true });

  wiggle.play();

  $(window).mousemove(function (e) {
    $('.cursor').css({
      'transform': `translate(${e.clientX}px, ${e.clientY}px)` });

    anime({
      targets: ".tail",
      marginLeft: e.clientX,
      marginTop: e.clientY,
      easing: "easeOutElastic",
      duration: 1200 });

  });

  $('.cursor-change, .button, a').mouseenter(function () {
    $('.cursor, .tail').addClass('hover');
  });
  $('.cursor-change, .button, a').mouseleave(function () {
    $('.cursor, .tail').removeClass('hover');
  });

  // End of On ready
});

$('#play').on('click', function(e) {
	e.preventDefault();
	$("#player")[0].src += "?autoplay=1";
	$('#player').show();
	$('#video-cover').hide();
	$('#play').hide();
})
